/* workingIdentity.js — "Who's working?" picker for shared departmental (officer-level)
   logins. IT provisions ONE login/password per shared officer group; this picker then
   sets the WORKING IDENTITY so My Work stays personal and the audit trail stays
   individual. Managers, Finance and Stakeholders use fixed individual/shared identities
   and never see this picker.

   Mechanism: picking a person sets state.officer (code + fullName) — the same field the
   whole app already keys personal work and attribution on — then refreshes the chrome. */
(function () {
  // The 5 shared officer-level roles that use one login for several people.
  // Shared departmental logins that use the "Who's working?" picker. Supervisors and
  // Officers have SEPARATE shared credentials (segregation of duties): an Officer login
  // can never surface a Supervisor identity, and vice-versa.
  const SHARED_OFFICER_ROLES = new Set([
    // Supervisor-level shared logins
    'procurement_technical_supervisor',
    'procurement_indirect_supervisor',
    'sc_supervisor',
    // Officer-level shared logins
    'procurement_technical_officer',
    'procurement_indirect_officer',
    'sc_officer',
    'logistics_officer',
    'demand_officer'
  ]);

  // Which people each shared login may pick from. Each login shows ONLY its own tier, so
  // the supervisor/officer boundary is enforced by the credential, not the honour system.
  const GROUP_ROLES = {
    // Supervisor logins → supervisors only
    procurement_technical_supervisor: ['procurement_technical_supervisor'],
    procurement_indirect_supervisor:  ['procurement_indirect_supervisor'],
    sc_supervisor:                    ['sc_supervisor'],
    // Officer logins → officers only
    procurement_technical_officer: ['procurement_technical_officer'],
    procurement_indirect_officer:  ['procurement_indirect_officer'],
    sc_officer:                    ['sc_officer'],
    logistics_officer:             ['logistics_officer'],
    demand_officer:                ['demand_officer']
  };

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, c =>
      ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));
  }

  // Demo-only sample roster (used when the officers collection has no stream-tagged people).
  const DEMO_ROSTER = {
    procurement_technical_supervisor: [{ code: 'BB', fullName: 'Bryan Bottine', role: 'procurement_technical_supervisor' }],
    procurement_technical_officer:    [{ code: 'SL', fullName: 'S. Lim', role: 'procurement_technical_officer' }, { code: 'HG', fullName: 'H. Grenade', role: 'procurement_technical_officer' }],
    procurement_indirect_supervisor:  [{ code: 'IS', fullName: 'I. Supervisor', role: 'procurement_indirect_supervisor' }],
    procurement_indirect_officer:     [{ code: 'IO', fullName: 'I. Officer', role: 'procurement_indirect_officer' }],
    sc_supervisor:                    [{ code: 'SC', fullName: 'SC Supervisor', role: 'sc_supervisor' }],
    sc_officer:                       [{ code: 'SP', fullName: 'SC Specialist', role: 'sc_officer' }],
    logistics_officer:                [{ code: 'LO', fullName: 'Logistics Officer', role: 'logistics_officer' }],
    demand_officer:                   [{ code: 'DP', fullName: 'Demand Planner', role: 'demand_officer' }]
  };
  function initials(code, name) {
    if (code) return String(code).slice(0, 2).toUpperCase();
    const p = String(name || '').trim().split(/\s+/);
    return ((p[0] || '')[0] || '' + (p[1] || '')[0] || '').toUpperCase() || '?';
  }
  function isSupervisorRole(r) { return /(_manager|_supervisor)$/.test(r || ''); }

  function activeSharedRole() {
    const r = (typeof window.__currentRole === 'function') ? window.__currentRole()
            : (window.__state && window.__state.officer && window.__state.officer.role);
    return SHARED_OFFICER_ROLES.has(r) ? r : null;
  }

  // People eligible for the current shared login: officers whose role is in the group.
  function peopleForGroup(sharedRole) {
    const roles = GROUP_ROLES[sharedRole] || [];
    const officers = (window.__state && window.__state.data && window.__state.data.officers) || [];
    const real = officers.filter(o => o.active !== false && roles.includes(o.role));
    if (real.length) return real;
    // Demo fallback: if no real officers carry this stream role yet (common in the demo,
    // where the officers collection isn't seeded with stream-tagged people), show a small
    // sample roster so the picker is demonstrable. Production uses the real records above.
    if (window.APP_CONFIG && window.APP_CONFIG.demoMode) {
      return (DEMO_ROSTER[sharedRole] || []);
    }
    return real;
  }

  function deptLabel() {
    return (typeof window.departmentLabel === 'function') ? window.departmentLabel() : 'Department';
  }

  const ROLE_LABELS = {
    procurement_technical_supervisor: 'Procurement Supervisor',
    procurement_technical_officer: 'Procurement Officer',
    procurement_indirect_supervisor: 'Procurement Supervisor',
    procurement_indirect_officer: 'Procurement Officer',
    sc_supervisor: 'Supply Chain Supervisor',
    sc_officer: 'Supply Chain Officer (Specialist)',
    logistics_officer: 'Logistics Officer',
    demand_officer: 'Demand Planning Officer'
  };
  function labelFor(role) {
    if (ROLE_LABELS[role]) return ROLE_LABELS[role];
    if (typeof window.roleLabel === 'function') { try { return window.roleLabel(role); } catch (_) {} }
    return role || '';
  }

  function personRow(o) {
    const roleLbl = labelFor(o.role);
    const code = esc(o.code), name = esc(o.fullName || o.code);
    // Click handling is done by the delegated capture-phase listener below (proven to
    // fire reliably). No inline onclick, to avoid a double-fire.
    return `<div class="who-person" data-code="${code}" data-name="${name}">
      <div class="av">${esc(initials(o.code, o.fullName))}</div>
      <div><div class="nm">${esc(o.fullName || o.code)}</div><div class="rl">${esc(roleLbl)}</div></div>
      <span class="go">›</span></div>`;
  }

  function buildPickerHtml(sharedRole) {
    const people = peopleForGroup(sharedRole);
    const supers = people.filter(o => isSupervisorRole(o.role));
    const officers = people.filter(o => !isSupervisorRole(o.role));
    const list = arr => `<div class="who-list">${arr.map(personRow).join('')}</div>`;
    const emptyNote = `<p class="text-sm text-muted" style="padding:8px 0">No people are registered for this workspace yet. An administrator can add them in System Settings → Officers &amp; Roles.</p>`;
    return `<div class="who-picker">
      <div class="who-head">
        <button class="who-close" type="button" aria-label="Close" title="Close">✕</button>
        <span class="badge-dept">${esc(deptLabel())}</span>
        <h2>Who's working?</h2>
        <p>You're signed in to a shared department workspace. Pick your name so your task list loads and your actions are recorded under you.</p>
      </div>
      <div class="who-body">
        ${supers.length ? `<div class="who-group-hd">Supervisors</div>${list(supers)}` : ''}
        ${officers.length ? `<div class="who-group-hd">Officers</div>${list(officers)}` : ''}
        ${(!supers.length && !officers.length) ? emptyNote : ''}
      </div>
      <div class="who-foot">🔒 Shared department login (officer level) · You can switch person anytime from the top-right menu · Actions are attributed to the selected person.</div>
    </div>`;
  }

  function setWorkingIdentity(code, name) {
    if (!window.__state) return;
    // Create the officer object if it doesn't exist yet (e.g. in demo/role-switch mode),
    // rather than silently doing nothing — this was blocking the pick from registering.
    const prevRole = (window.__state.officer && window.__state.officer.role)
      || (typeof window.__currentRole === 'function' ? window.__currentRole() : null);
    window.__state.officer = Object.assign({}, window.__state.officer || {}, {
      code: code, fullName: name, role: prevRole
    });
    try { sessionStorage.setItem('phoenix_working_identity', JSON.stringify({ code: code, name: name })); } catch (_) {}
    // Refresh chrome + any open personal views.
    const un = document.getElementById('user-name'); if (un) un.textContent = name;
    const ua = document.getElementById('user-avatar'); if (ua) ua.textContent = initials(code, name);
    if (typeof window.updateUserChip === 'function') window.updateUserChip();
    if (window.PXUtils && window.PXUtils.toast) window.PXUtils.toast('Now working as ' + name, 'success');
    if (window.__renderers && window.__state.view && window.__renderers[window.__state.view]) {
      try { window.__renderers[window.__state.view](); } catch (_) {}
    }
  }

  // Global handler for the inline onclick on each person row — the most robust wiring
  // (no listener timing, no delegation, no closure scope issues).
  window.__pickWorkingIdentity = function (code, name) {
    try {
      setWorkingIdentity(code, name);
      console.info('[who-working] switched to:', code, name, '| user-name now:', (document.getElementById('user-name') || {}).textContent);
      // Close the picker modal DIRECTLY (don't route through the card-page-wrapped
      // closeModal, which could misinterpret the view and fail to close the picker).
      const bd = document.getElementById('modal-backdrop');
      const m = document.getElementById('modal');
      if (bd) bd.classList.remove('show', 'who-picker-backdrop');
      if (m) { m.classList.remove('who-picker-modal'); m.innerHTML = ''; }
    } catch (e) {
      console.error('[who-working] pick failed', e);
      if (window.PXUtils && window.PXUtils.toast) window.PXUtils.toast('Could not switch — see console.', 'danger');
    }
  };

  function wirePicker(container) {
    container.querySelectorAll('.who-person').forEach(row => {
      row.addEventListener('click', () => {
        setWorkingIdentity(row.getAttribute('data-code'), row.getAttribute('data-name'));
        if (typeof window.closeModal === 'function') window.closeModal();
      });
    });
  }

  // Close/dismiss the picker without picking (so the user is never trapped and can reach
  // the role switcher). A closed picker won't re-prompt until next reload.
  function dismissPicker() {
    const bd = document.getElementById('modal-backdrop');
    const m = document.getElementById('modal');
    if (bd) bd.classList.remove('show', 'who-picker-backdrop');
    if (m) { m.classList.remove('who-picker-modal'); m.innerHTML = ''; }
    // Remember the dismissal so we don't auto-reprompt and trap the user this session.
    try { sessionStorage.setItem('phoenix_working_identity_dismissed', '1'); } catch (_) {}
  }
  window.__dismissWorkingIdentityPicker = dismissPicker;

  // Final safety net: an always-on delegated listener attached at module load. Even if the
  // inline onclick is somehow stripped or the row markup changes, this catches the click.
  // It also logs, so if a pick ever fails we can see why in the console.
  document.addEventListener('click', function (ev) {
    // Close button or backdrop click → dismiss without picking.
    if (ev.target.closest && ev.target.closest('.who-close')) { dismissPicker(); return; }
    if (ev.target.id === 'modal-backdrop' && document.querySelector('.who-picker')) { dismissPicker(); return; }
    const row = ev.target && ev.target.closest && ev.target.closest('.who-person');
    if (!row) return;
    const code = row.getAttribute('data-code');
    const name = row.getAttribute('data-name');
    console.info('[who-working] row clicked:', code, name);
    if (code && typeof window.__pickWorkingIdentity === 'function') {
      window.__pickWorkingIdentity(code, name);
    } else {
      console.warn('[who-working] pick handler unavailable or no code', { code, hasHandler: typeof window.__pickWorkingIdentity });
    }
  }, true);   // capture phase — runs before anything that might stop propagation

  // Public: open the picker (used on load for shared logins + "Switch person").
  function openWorkingIdentityPicker(force) {
    const sharedRole = activeSharedRole();
    if (!sharedRole && !force) return false;
    const roleForPicker = sharedRole || activeSharedRole();
    if (!roleForPicker) return false;
    if (typeof window.openModal !== 'function') return false;
    window.openModal(buildPickerHtml(roleForPicker), false);
    // Tag the modal + backdrop so the picker gets its own centered, self-sizing layout
    // (not the top-anchored order-detail modal constraints that were clipping the footer).
    const backdrop = document.getElementById('modal-backdrop');
    const modalEl = document.getElementById('modal');
    if (backdrop) backdrop.classList.add('who-picker-backdrop');
    if (modalEl) modalEl.classList.add('who-picker-modal');
    // The modal host wraps our html; wire after it's in the DOM.
    setTimeout(() => {
      const host = document.querySelector('.modal .who-picker') || document.querySelector('.who-picker');
      if (host) wirePicker(host);
    }, 0);
    return true;
  }
  window.openWorkingIdentityPicker = openWorkingIdentityPicker;

  // Restore a working identity chosen earlier this session (so a re-render doesn't reset it).
  function restoreWorkingIdentity() {
    if (!activeSharedRole()) return false;
    try {
      const saved = JSON.parse(sessionStorage.getItem('phoenix_working_identity') || 'null');
      if (saved && saved.code) { setWorkingIdentity(saved.code, saved.name); return true; }
    } catch (_) {}
    return false;
  }
  window.__restoreWorkingIdentity = restoreWorkingIdentity;

  // On load: if this is a shared officer login and no identity chosen yet, prompt.
  function maybePromptOnLoad() {
    if (!activeSharedRole()) return;
    if (restoreWorkingIdentity()) return;  // already picked this session
    try { if (sessionStorage.getItem('phoenix_working_identity_dismissed') === '1') return; } catch (_) {}
    openWorkingIdentityPicker(false);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => setTimeout(maybePromptOnLoad, 400));
  } else {
    setTimeout(maybePromptOnLoad, 400);
  }
})();
