PHOENIX PROCUREMENT — PRODUCTION CONFIGURATION (READ ME FIRST)
=========================================================

>>> WHICH FILE DO I OPEN FOR THE PRODUCTION? <<<
    Open:  dist/phoenix-procurement-PRODUCTION.html
    (Double-click it, or open it in any modern browser — Chrome/Edge recommended.)

That single file IS the PRODUCTION. There is no separate "BC" version to hunt for —
the Business Central look is built in and ON by default.

dist/ NOW CONTAINS EXACTLY ONE PRODUCTION FILE (no duplicates to test by mistake):
  - phoenix-procurement-PRODUCTION.html .............. the tester-facing PRODUCTION file (OPEN THIS)
  (The old phoenix-procurement-no-login.html and phoenix-procurement-BC-STRUCTURE-PRODUCTION.html
   were byte-identical copies and have been removed to avoid confusion.)

WHAT THIS BUILD IS:
  - PRODUCTIONMode = true (src/core.js): role switcher + multi-tab roles ENABLED, NO real login.
  - Business Central-style UI (top-nav, ribbon, card page, FactBox) with Phoenix branding.
  - Works across all three entities: Phoenix, Seychelles Breweries, Edena.
  - DO NOT deploy this PRODUCTION file to a live server (no auth).

TO REBUILD FROM SOURCE:
    python3 build.py
  This regenerates dist/phoenix-procurement-PRODUCTION.html + runs syntax and structural invariant checks.

FOR PRODUCTION:
  Use the PRODUCTION package instead (PRODUCTIONMode = false; role switcher removed).
  See HANDOVER-TO-IT.md for deployment and Firebase/Firestore notes.

