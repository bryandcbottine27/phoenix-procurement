/* ============================================================
   LEGACY PLACEHOLDER
   ============================================================
   The active ERP Excel import engine is:

     src/modules/reports/erpImport.js

   This historical top-level file is intentionally kept as a pointer only. It is
   not loaded by index.html or build.py and must not define window.PXPoImport,
   otherwise it could override the maintained importer.

   Current supported import sheets:
   - FPO: Phoenix foreign, Navision
   - LPO: Phoenix local, Navision
   - Seybrew: Seychelles Breweries, Business Central
   - Edena / Edena Export: Edena, Business Central

   Business Central local-order rule:
   - Seychelles Breweries: blank Currency Code or SCR = local
   - Edena: blank Currency Code or EUR = local
   - non-local populated currency = foreign
*/
