/* ============================================================
   XLSX READER  (dependency-free)
   ============================================================
   Reads an .xlsx (a ZIP of XML parts) entirely in the browser with no external
   libraries. ZIP entries are STORED or DEFLATE; DEFLATE is inflated with the
   native DecompressionStream('deflate-raw'). Parses sharedStrings.xml and each
   worksheet into arrays of row-objects keyed by the header row.

   Exposes window.PXXlsxReader.readWorkbook(arrayBuffer) -> Promise<{
     sheetNames: [...],
     sheets: { <name>: { headers:[...], rows:[ {header: value} ] } }
   }>
   Cell values: numbers stay numbers; dates (numFmt) convert to JS Date; text via
   inline or shared strings. */
(function () {
  const td = new TextDecoder();

  // ---- minimal ZIP central-directory reader ----
  function u16(b, o) { return b[o] | (b[o + 1] << 8); }
  function u32(b, o) { return (b[o] | (b[o + 1] << 8) | (b[o + 2] << 16) | (b[o + 3] << 24)) >>> 0; }

  async function inflateRaw(bytes) {
    // Native, no library. deflate-raw = no zlib header (matches ZIP method 8).
    const ds = new DecompressionStream('deflate-raw');
    const stream = new Response(new Blob([bytes])).body.pipeThrough(ds);
    const buf = await new Response(stream).arrayBuffer();
    return new Uint8Array(buf);
  }

  async function unzip(arrayBuffer) {
    const b = new Uint8Array(arrayBuffer);
    // Find End Of Central Directory (EOCD): signature 0x06054b50, scan from end.
    let eocd = -1;
    for (let i = b.length - 22; i >= 0 && i >= b.length - 22 - 65536; i--) {
      if (u32(b, i) === 0x06054b50) { eocd = i; break; }
    }
    if (eocd < 0) throw new Error('Not a valid .xlsx (no ZIP end record).');
    const cdCount = u16(b, eocd + 10);
    let cdOff = u32(b, eocd + 16);
    const files = {};
    for (let n = 0; n < cdCount; n++) {
      if (u32(b, cdOff) !== 0x02014b50) break;
      const method = u16(b, cdOff + 10);
      const compSize = u32(b, cdOff + 20);
      const nameLen = u16(b, cdOff + 28);
      const extraLen = u16(b, cdOff + 30);
      const commentLen = u16(b, cdOff + 32);
      const localOff = u32(b, cdOff + 42);
      const name = td.decode(b.subarray(cdOff + 46, cdOff + 46 + nameLen));
      // Read local header to find the actual data start (local extra len can differ).
      const lhNameLen = u16(b, localOff + 26);
      const lhExtraLen = u16(b, localOff + 28);
      const dataStart = localOff + 30 + lhNameLen + lhExtraLen;
      const raw = b.subarray(dataStart, dataStart + compSize);
      files[name] = { method, raw };
      cdOff += 46 + nameLen + extraLen + commentLen;
    }
    // Decompress on demand
    const out = {};
    for (const name of Object.keys(files)) {
      const f = files[name];
      let data;
      if (f.method === 0) data = f.raw;                 // STORED
      else if (f.method === 8) data = await inflateRaw(f.raw); // DEFLATE
      else continue;                                    // unsupported method
      out[name] = td.decode(data);
    }
    return out;
  }

  // ---- tiny XML helpers (attribute + tag scanning; no DOM needed) ----
  function attr(tag, name) {
    const m = tag.match(new RegExp(name + '="([^"]*)"'));
    return m ? m[1] : null;
  }
  function xmlUnescape(s) {
    return s.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"')
            .replace(/&apos;/g, "'").replace(/&#(\d+);/g, (_, d) => String.fromCharCode(+d))
            .replace(/&amp;/g, '&');
  }

  function parseSharedStrings(xml) {
    if (!xml) return [];
    const out = [];
    // each <si> ... </si> ; text is in <t>..</t> possibly across runs <r><t>..
    const siRe = /<si>([\s\S]*?)<\/si>/g; let m;
    while ((m = siRe.exec(xml))) {
      const inner = m[1];
      let text = '';
      const tRe = /<t[^>]*>([\s\S]*?)<\/t>/g; let tm;
      while ((tm = tRe.exec(inner))) text += tm[1];
      out.push(xmlUnescape(text));
    }
    return out;
  }

  // Excel serial date → JS Date (1900 date system, with the well-known 1900 leap bug).
  function excelDateToJS(serial) {
    if (serial == null || isNaN(serial)) return null;
    const n = Number(serial);
    if (n <= 0 || n > 2958465) return null; // out of sane range
    const ms = Math.round((n - 25569) * 86400 * 1000); // 25569 = days from 1899-12-30 to 1970-01-01
    const d = new Date(ms);
    return isNaN(d) ? null : d;
  }

  // Determine which numFmtIds / style indexes are dates (best-effort from styles.xml).
  function parseDateStyles(stylesXml) {
    const dateXf = new Set();
    if (!stylesXml) return dateXf;
    // Built-in date numFmtIds: 14-22, 45-47. Plus custom formats containing d/m/y and no currency.
    const customDateFmts = new Set();
    const fmtRe = /<numFmt[^>]*numFmtId="(\d+)"[^>]*formatCode="([^"]*)"/g; let fm;
    while ((fm = fmtRe.exec(stylesXml))) {
      const id = +fm[1]; const code = fm[2].toLowerCase();
      if (/[dmy]/.test(code) && !/[#0]/.test(code.replace(/[^#0]/g, '')) ) customDateFmts.add(id);
      else if (/(yy|mm|dd|d\/|m\/|\bh:)/.test(code)) customDateFmts.add(id);
    }
    const builtinDate = new Set([14,15,16,17,18,19,20,21,22,45,46,47]);
    // cellXfs: each <xf> in order; index = style index used by cells (s="..")
    const xfsBlock = (stylesXml.match(/<cellXfs[^>]*>([\s\S]*?)<\/cellXfs>/) || [])[1] || '';
    const xfRe = /<xf\b[^>]*\/?>/g; let xf; let idx = 0;
    while ((xf = xfRe.exec(xfsBlock))) {
      const numFmtId = +(attr(xf[0], 'numFmtId') || 0);
      if (builtinDate.has(numFmtId) || customDateFmts.has(numFmtId)) dateXf.add(idx);
      idx++;
    }
    return dateXf;
  }

  function colToIndex(ref) { // "B7" -> 1 (zero-based col)
    const m = ref.match(/^([A-Z]+)/); if (!m) return 0;
    let n = 0; for (const ch of m[1]) n = n * 26 + (ch.charCodeAt(0) - 64);
    return n - 1;
  }

  function parseSheet(xml, shared, dateXf) {
    const rows = [];
    const rowRe = /<row[^>]*>([\s\S]*?)<\/row>/g; let rm;
    while ((rm = rowRe.exec(xml))) {
      const cells = [];
      const cellRe = /<c\b([^>]*)(?:\/>|>([\s\S]*?)<\/c>)/g; let cm;
      while ((cm = cellRe.exec(rm[1]))) {
        const ctag = cm[1]; const cbody = cm[2] || '';
        const ref = attr('<c ' + ctag + '>', 'r') || '';
        const ci = ref ? colToIndex(ref) : cells.length;
        const t = attr('<c ' + ctag + '>', 't');     // s=shared, inlineStr, str, b
        const sIdx = attr('<c ' + ctag + '>', 's');   // style index
        let val = null;
        if (t === 'inlineStr') {
          const im = cbody.match(/<t[^>]*>([\s\S]*?)<\/t>/);
          val = im ? xmlUnescape(im[1]) : '';
        } else {
          const vm = cbody.match(/<v>([\s\S]*?)<\/v>/);
          const raw = vm ? vm[1] : null;
          if (raw == null) val = null;
          else if (t === 's') val = shared[+raw] != null ? shared[+raw] : '';
          else if (t === 'str') val = xmlUnescape(raw);
          else if (t === 'b') val = raw === '1';
          else {
            // numeric — could be a date depending on style
            const num = Number(raw);
            if (sIdx != null && dateXf.has(+sIdx)) val = excelDateToJS(num) || num;
            else val = num;
          }
        }
        cells[ci] = val;
      }
      rows.push(cells);
    }
    return rows;
  }

  async function readWorkbook(arrayBuffer) {
    const parts = await unzip(arrayBuffer);
    const shared = parseSharedStrings(parts['xl/sharedStrings.xml']);
    const dateXf = parseDateStyles(parts['xl/styles.xml']);

    // workbook.xml maps sheet name -> r:id ; workbook.xml.rels maps r:id -> target file
    const wb = parts['xl/workbook.xml'] || '';
    const rels = parts['xl/_rels/workbook.xml.rels'] || '';
    const relMap = {};
    const relRe = /<Relationship\b[^>]*\/>/g; let rl;
    while ((rl = relRe.exec(rels))) {
      const id = attr(rl[0], 'Id'); let target = attr(rl[0], 'Target');
      if (id && target) { if (!target.startsWith('xl/') && !target.startsWith('/')) target = 'xl/' + target; relMap[id] = target.replace(/^\//, ''); }
    }
    const sheetNames = []; const sheetFiles = {};
    const shRe = /<sheet\b[^>]*\/?>/g; let sh; let fallback = 1;
    while ((sh = shRe.exec(wb))) {
      const name = xmlUnescape(attr(sh[0], 'name') || ('Sheet' + fallback));
      const rid = attr(sh[0], 'r:id') || attr(sh[0], 'r:Id');
      let file = rid && relMap[rid] ? relMap[rid] : ('xl/worksheets/sheet' + fallback + '.xml');
      sheetNames.push(name); sheetFiles[name] = file; fallback++;
    }

    const sheets = {};
    for (const name of sheetNames) {
      const xml = parts[sheetFiles[name]];
      if (!xml) { sheets[name] = { headers: [], rows: [] }; continue; }
      const grid = parseSheet(xml, shared, dateXf);
      if (!grid.length) { sheets[name] = { headers: [], rows: [] }; continue; }
      const headers = (grid[0] || []).map(h => (h == null ? '' : String(h).trim()));
      const rows = [];
      for (let r = 1; r < grid.length; r++) {
        const arr = grid[r] || [];
        if (!arr.some(v => v !== null && v !== undefined && v !== '')) continue; // skip blank rows
        const obj = {};
        for (let c = 0; c < headers.length; c++) { if (headers[c]) obj[headers[c]] = arr[c] != null ? arr[c] : ''; }
        rows.push(obj);
      }
      sheets[name] = { headers, rows };
    }
    return { sheetNames, sheets };
  }

  window.PXXlsxReader = { readWorkbook };
})();
