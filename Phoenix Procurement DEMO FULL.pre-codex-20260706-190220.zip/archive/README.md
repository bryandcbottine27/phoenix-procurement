# Archive folder

This folder documents the **old "bundle" files** that no longer exist in the project.

## The old bundle files and what replaced them

During the modular refactor, the app was split out of a single HTML file. Temporary
combined files named `*.bundle.js` existed along the way. They have all been
**renamed or split, then deleted**:

| Old file (no longer exists) | Replaced by |
|---|---|
| `src/core.bundle.js` | `src/core.js` |
| `src/operational.bundle.js` | `src/operational.js` |
| `src/modules/orders/orders.bundle.js` | `orders.{service,render,form,detail}.js` |
| `src/modules/shipments/shipments.bundle.js` | `shipments.{service,render,form,detail}.js` |
| `src/modules/payments/payments.bundle.js` | `payments.{service,render,form,detail}.js` |
| `src/modules/suppliers/suppliers.bundle.js` | `suppliers.{service,render,form}.js` |
| `src/modules/reports/reports.bundle.js` | `reports.{service,render,form}.js` |

**None of these `*.bundle.js` files are present in this project (the zip).** There is
nothing here to restore and nothing to edit. The active source is only under `/src`.

## ⚠️ If you STILL see `*.bundle.js` files in your /src folder on your computer

That means your local/OneDrive folder has **stale leftovers from an older copy** —
they were never part of these newer builds, and unzipping a new version on top of an
old folder does not delete old files. They are NOT loaded by the app (neither
`build.py` nor `index.html` references them), but they can confuse you into editing
the wrong file.

**To remove them, run the cleanup script in the project root:**

- Windows: double-click **`cleanup-old-bundles.bat`**
- Mac/Linux: run **`./cleanup-old-bundles.sh`**

Each script only deletes the seven known old bundle filenames listed above — nothing
else. After running it, your folder will match the project: active source under
`/src`, no `*.bundle.js` files.

## Superseded standalone source files (moved here during the pre-Go-Live cleanup)

These files were kept in `src/` but were **not loaded** by `build.py` / `index.html`.
Their functionality now lives inside the active modules, so they were moved to
`archive/superseded-src/` to remove duplicate-purpose files from the active tree.

| Moved file | Superseded by / reason |
|---|---|
| `src/poImport.js` | Legacy placeholder pointer. The active ERP Excel import engine is `src/modules/reports/erpImport.js` (defines `window.PXPoImport`). |
| `src/xlsxReader.js` | Standalone no-library XLSX reader. The same reader is now self-contained inside `src/modules/reports/erpImport.js` (defines `window.PXXlsxReader`). |

Do not reintroduce these into `src/` — they would duplicate the active implementations.
