PHOENIX PROCUREMENT — PRODUCTION CONFIGURATION (READ ME FIRST)
=========================================================

>>> WHICH FILE DO I OPEN FOR PRODUCTION? <<<
    Open:  dist/phoenix-procurement-PRODUCTION.html
    (Double-click it, or open it in any modern browser — Chrome/Edge recommended.)

That single file IS the production app. There is no separate "BC" version to hunt for —
the Business Central look is built in and ON by default.

dist/ NOW CONTAINS EXACTLY ONE PRODUCTION FILE (no duplicates to test by mistake):
  - phoenix-procurement-PRODUCTION.html ........ the production app file (OPEN THIS)
  (The old phoenix-procurement-no-login.html and phoenix-procurement-BC-STRUCTURE-DEMO.html
   were byte-identical copies and have been removed to avoid confusion.)

WHAT THIS BUILD IS:
  - demoMode = false (src/core.js): demo role switcher and no-login testing aids DISABLED.
  - Business Central-style UI (top-nav, ribbon, card page, FactBox) with Phoenix branding.
  - Works across all three entities: Phoenix, Seychelles Breweries, Edena.
  - Use only after Firebase/SSO, Firestore rules and officer login mapping are configured.

TO REBUILD FROM SOURCE:
    python3 build.py
  This regenerates dist/phoenix-procurement-PRODUCTION.html + runs syntax and structural invariant checks.

FOR DEMO TESTING:
  Use the DEMO package instead.
  See HANDOVER-TO-IT.md for deployment and Firebase/Firestore notes.
